<html>
<head>
    <style>
        #invoice-POS{
            box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
            padding:2mm;
            margin: 0 auto;
            width: 44mm;
            background: #FFF;

        }
        ::selection {background: #f31544; color: #FFF;}
        ::moz-selection {background: #f31544; color: #FFF;}
        h1{
            font-size: 1.5em;
            color: #222;
        }
        h2{font-size: .9em;}
        h3{
            font-size: 1.2em;
            font-weight: 300;
            line-height: 2em;
        }
        p{
            font-size: .7em;
            color: #666;
            line-height: 1.2em;
        }

        #top, #mid,#bot{ /* Targets all id with 'col-' */
            border-bottom: 1px solid #EEE;
        }

        #top{min-height: 100px;}
        #mid{min-height: 80px;}
        #bot{ min-height: 50px;}

        #top .logo{
        //float: left;
            height: 60px;
            width: 60px;
            /*background: url(http://michaeltruong.ca/images/logo1.png) no-repeat;*/
            background-size: 60px 60px;
        }
        .clientlogo{
            float: left;
            height: 60px;
            width: 60px;
            background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;
            background-size: 60px 60px;
            border-radius: 50px;
        }
        .info{
            display: block;
        //float:left;
            margin-left: 0;
        }
        .title{
            float: right;
        }
        .title p{text-align: right;}
        table{
            width: 100%;
            border-collapse: collapse;
        }
        td{
        //padding: 5px 0 5px 15px;
        //border: 1px solid #EEE
        }
        .tabletitle{
        //padding: 5px;
            font-size: .5em;
            background: #EEE;
        }
        .service{border-bottom: 1px solid #EEE;}
        .item{width: 24mm;}
        .itemtext{font-size: .5em;}

        #legalcopy{
            margin-top: 5mm;
        }



    </style>
</head>
<body>

<div id="invoice-POS">

    <center id="top">
        <div class="logo"></div>
        <div class="info">
            <h2>SBISTechs Inc</h2>
        </div><!--End Info-->
    </center><!--End InvoiceTop-->

    <div id="mid">
        <div class="info">
            <h2>Contact Info</h2>
            <p>
                Address : street city, state 0000</br>
                Email   : JohnDoe@gmail.com</br>
                Phone   : 555-555-5555</br>
            </p>
        </div>
    </div><!--End Invoice Mid-->

    <div id="bot">

        <div id="table">
            <table>
                <tr class="tabletitle">
                    <td class=""><h2>#</h2></td>
                    <td class=""><h2>Name</h2></td>
                    <td class=""><h2>Quantity</h2></td>
                    <td class=""><h2>Price</h2></td>
                    <td class=""><h2>Discount</h2></td>
                </tr>
                <?php $total = 0; ?>
                <?php $__currentLoopData = $cartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr class="service">
                    <td class="tableitem"><p class="itemtext"><?php echo e($loop->index+1); ?></p></td>
                    <td class="tableitem"><p class="itemtext"><?php echo e($item->name); ?></p></td>
                    <td class="tableitem"><p class="itemtext"><?php echo e($item->quantity); ?></p></td>
                    <td class="tableitem"><p class="itemtext"><?php echo e($item->price); ?></p></td>
                    <td class="tableitem"><p class="itemtext"><?php echo e($item->discount); ?>%</p></td>
                    <?php
                    $subTotal = $item->price*$item->quantity -  $item->discount/100*($item->price*$item->quantity);
                    $total = $total + $subTotal;
                    ?>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr class="tabletitle">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="Rate"><h2>Total Amount</h2></td>
                    <td class="payment"><h2><?php echo e(ceil($total)); ?></h2></td>
                </tr>
                <?php $receive = session('receive')?>

                <tr class="tabletitle">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="Rate"><h2>Return Amount</h2></td>
                    <td class="payment"><h2><?php echo e($receive - ceil($total)); ?></h2></td>
                </tr>

            </table>
        </div><!--End Table-->

        <div id="legalcopy" >
            <p class="legal"><strong>Thank you for your business!</strong>  Payment is expected within 31 days; please process this invoice within that time. There will be a 5% interest charge per month on late invoices.
            </p>
        </div>

    </div><!--End InvoiceBot-->
</div><!--End Invoice-->
<a href="<?php echo e(route('printReceipt')); ?>" class="btn btn-success" target="_blank" style="text-decoration: none; padding: 5px 15px; background-color: black; color: white;"> print </a>
















</body>
</html>
<?php /**PATH C:\xampp\htdocs\pos (2)\pos\resources\views/receipt.blade.php ENDPATH**/ ?>