<?php if(auth()->check() && auth()->user()->hasRole('Cashier')): ?>
    <?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin|Inventory')): ?>
<?php echo $__env->make('adminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH /home/pu259pagr0se/public_html/POSfinal/resources/views/welcome.blade.php ENDPATH**/ ?>