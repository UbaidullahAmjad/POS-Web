<?php $__env->startSection('title','Assign Role'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="<?php echo e(route('assigned_role')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <div class="input-group">
                <select class="form-control" name="role_id">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role->name != 'SuperAdmin'): ?>
                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div><br>
        <div class="form-group">
            <div class="input-group">
                <select class="form-control" name="user_id">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$user->hasRole("SuperAdmin")): ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>

        <input type="submit" class="btn btn-outline-primary m-2">
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CplusSoft\showkat\POS\resources\views/admin/assign_role.blade.php ENDPATH**/ ?>