<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>
<div class="content d-flex flex-column flex-column-fluid" id="tc_content">
    <!--begin::Subheader-->
    
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container-fluid addproduct-main">

            <div class="row">
                <div class="col-lg-12 col-xl-12">
                    <div class="card card-custom gutter-b bg-transparent shadow-none border-0">
                        <div class="card-header align-items-center   border-bottom-dark px-0">
                            <div class="card-title mb-0">
                                <h3 class="card-label mb-0 font-weight-bold text-body">Add Product
                                </h3>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-xl-12">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
                            <div class="card card-custom gutter-b bg-white border-0">
                                <div class="card-header border-0 align-items-center">
                                    <h3 class="card-label mb-0 font-weight-bold text-body">Add Product
                                    </h3>
                                </div>


                                <div class="card-body" id="printableTable">
                                    <div class="row">
                                        <div class="col-md-12 col-12">
                                            <form action="<?php echo e(route('products.store')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                
                                                <label>Categories</label>
                                                <select class="single-select w-100 mb-3 categories-select"
                                                    name="category_id">
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="tab-content lang-content" id="v-pills-tabContent">
                                                            <div class="tab-pane fade show active" id="home-basic"
                                                                role="tabpanel" aria-labelledby="home-tab-basic">
                                                                <h6 class="text-body">
                                                                    Product Name
                                                                </h6>
                                                                <fieldset class="form-group mb-3">
                                                                    <input type="text"
                                                                        class="form-control bg-transparent text-dark <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                         is-invalid
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="basicInput" name="name"
                                                                        placeholder="Product Name">
                                                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </fieldset>
                                                                <h6 class="text-body">
                                                                    In Stock
                                                                </h6>
                                                                <fieldset class="form-group mb-3">
                                                                    <input type="text"
                                                                        class="form-control bg-transparent text-dark <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                         is-invalid
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="basicInput" name="quantity"
                                                                        placeholder="Instock">
                                                                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </fieldset>
                                                                <h6 class="text-body">
                                                                    Price
                                                                </h6>
                                                                <fieldset class="form-group mb-3">
                                                                    <input type="text"
                                                                        class="form-control bg-transparent text-dark"
                                                                        id="basicInput" name="price"
                                                                        placeholder="Price">
                                                                </fieldset>
                                                                <h6 class="text-body">
                                                                    BarCode
                                                                </h6>
                                                                <fieldset class="form-group mb-3">
                                                                    <input type="number" name="barcode" autofocus
                                                                        class="form-control bg-transparent text-dark <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        is-invalid
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        id="basicInput" placeholder="BarCode">
                                                                        <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </fieldset>
                                                                <h6 class="text-body">
                                                                    Discount
                                                                </h6>
                                                                <fieldset class="form-group mb-3">
                                                                    <input type="number" name="discount"
                                                                        class="form-control bg-transparent text-dark"
                                                                        id="basicInput"
                                                                        placeholder="Enter Discount in %">
                                                                </fieldset>

                                                                <div class="col-12 d-flex justify-content-end">
                                                                    <input type="submit" href=""
                                                                        class="btn btn-primary cta">
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pu259pagr0se/public_html/POSfinal/resources/views/product/create.blade.php ENDPATH**/ ?>