<?php $__env->startSection('title','Stock'); ?>
<?php $__env->startSection('css'); ?>

<link href="<?php echo e(asset('assets/api/multiple-select/multiple-select.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/api/daterange-picker/daterangepicker.css')); ?>" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content d-flex flex-column flex-column-fluid" id="tc_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid">
        <div class="container-fluid">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-white mb-0 px-0 py-2">
                    <li class="breadcrumb-item " aria-current="page">Report</li>
                    <li class="breadcrumb-item active" aria-current="page">Stock Report</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-lg-12 col-xl-12">
                            <div class="card card-custom gutter-b bg-transparent shadow-none border-0">
                                <div class="card-header align-items-center  border-bottom-dark px-0">
                                    <div class="card-title mb-0">
                                        <h3 class="card-label mb-0 font-weight-bold text-body">Stock Report
                                        </h3>
                                    </div>
                                    <div class="icons d-flex">
                                        <a href="#" onclick="printDiv()" class="ml-2">
                                            <span
                                                class="icon h-30px font-size-h5 w-30px d-flex align-items-center justify-content-center rounded-circle ">
                                                <svg width="15px" height="15px" viewBox="0 0 16 16"
                                                    class="bi bi-printer-fill" fill="currentColor"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5 1a2 2 0 0 0-2 2v1h10V3a2 2 0 0 0-2-2H5z" />
                                                    <path fill-rule="evenodd"
                                                        d="M11 9H5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1z" />
                                                    <path fill-rule="evenodd"
                                                        d="M0 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-1v-2a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2H2a2 2 0 0 1-2-2V7zm2.5 1a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z" />
                                                </svg>
                                            </span>

                                        </a>
                                        <a href="#" class="ml-2">
                                            <span
                                                class="icon h-30px font-size-h5 w-30px d-flex align-items-center justify-content-center rounded-circle ">
                                                <svg width="15px" height="15px" viewBox="0 0 16 16"
                                                    class="bi bi-file-earmark-text-fill" fill="currentColor"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd"
                                                        d="M2 2a2 2 0 0 1 2-2h5.293A1 1 0 0 1 10 .293L13.707 4a1 1 0 0 1 .293.707V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm7 2l.5-2.5 3 3L10 5a1 1 0 0 1-1-1zM4.5 8a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7zM4 10.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5z" />
                                                </svg>
                                            </span>

                                        </a>

                                    </div>
                                </div>

                            </div>


                        </div>
                    </div>
                
                    <div class="row">
                        <div class="col-12 ">
                            <div class="card card-custom gutter-b bg-white border-0">
                                <div class="card-body">
                                    <div>
                                    <a href="#" class="btn btn-secondary" onclick="dailyStock()">Daily Stock</a>
                                   <a href="#" class="btn btn-primary" onclick="weeklyStock()">Weekly Stock</a>
                                   <a href="#" class="btn btn-info" onclick="monthlyStock()">Monthly Stock</a>
                                        <div class=" table-responsive" id="printableTable">
                                            <table id="productUnitTable" class="display ">

                                                <thead class="text-body">
                                                    <tr>
                                                        <th>Sr</th>
                                                        <th>Product</th>
                                                        <th class="">Unit Price</th>
                                                        <th class="">Current Stock</th>
                                                        <th class="">Total Unit Sale</th>
                                                    </tr>
                                                </thead>
                                                <?php
                                                    $total=0;
                                                    $totals=0;
                                                    ?>
                                                <tbody class="kt-table-tbody text-dark" id="stocks">
                                                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="kt-table-row kt-table-row-level-0">
                                                        <td><?php echo e($loop->index+1); ?></td>
                                                        <td class=""><?php echo e($record->name); ?></td>
                                                        <td><?php echo e($record->price); ?></td>
                                                        <td class=""> <?php echo e(($record->quantity-$record->sale_q)+$record->Re_q); ?></td>
                                                        <td class=""><?php echo e($record->sale_q-$record->Re_q); ?></td>
                                                    </tr>
                                                    <?php
                                                    $total = $total + $record->price;
                                                    $totals = $totals + (($record->quantity-$record->sale_q)+$record->Re_q) ;
                                                    ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     <!-- <tfoot>
                                                    <tr class="kt-table-row kt-table-row-level-0">

                                                        <th>Total</th>
                                                        <th class=""></th>
                                                        <th class=""><?php echo e($total); ?></th>
                                                        <th class=""><?php echo e($totals); ?></th>

                                                        <th class=""> </th>


                                                    </tr>

                                                </tfoot> -->
                                                </tbody>
                                              
                                            </table>
                                        </div>
                                    </div>


                                </div>
                            </div>

                        </div>

                    </div>
              
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('assets/api/multiple-select/multiple-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/api/daterange-picker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/api/daterange-picker/daterangepicker.min.js')); ?>"></script>

<script>
    jQuery(function() {
        jQuery('.english-select').multipleSelect({
      filter: true,
      filterAcceptOnEnter: true
    })
  });
  jQuery(function() {
        jQuery('.arabic-select').multipleSelect({
      filter: true,
      filterAcceptOnEnter: true
    })
  });
jQuery(document).ready( function () {
	jQuery('#productUnitTable').dataTable( {
    "pagingType": "simple_numbers",

    "columnDefs": [ {
      "targets"  : 'no-sort',
      "orderable": false,
    }]
});
});

jQuery(function() {

var start = moment().subtract(29, 'days');
var end = moment();

function cb(start, end) {
    jQuery('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
}

jQuery('#reportrange').daterangepicker({
    startDate: start,
    endDate: end,
    ranges: {
    //    'Today': [moment(), moment()],
    //    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    //    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    //    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    //    'This Month': [moment().startOf('month'), moment().endOf('month')],
    //    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    }
}, cb);

cb(start, end);

});

</script>
<script>
    
    function dailyStock()
    {
        var _token = $('input[name="_token"]').val();
        $.ajax({url: "<?php echo e(route('stock.day')); ?>",
                
        success: function(result)
        {    
            // console.log(result['daystock']);
            var len = 0;
            if(result['daystock'] != 0)
            {
                len = result['daystock'].length;
            }
            $('#stocks').empty();
            if(len > 0)
            {
                for(var i=0; i<len; i++)
                {
                    var id = result['daystock'][i].id;
                    var name = result['daystock'][i].name;
                    var price = result['daystock'][i].price;
                    var quantity = result['daystock'][i].quantity;
                    var discount = result['daystock'][i].discount;
                
                
                    var tr_str = "<tr>"+
                                "<td align='center'>"+(i+1)+"</td>"+
                                "<td align='center'>"+name+"</td>"+
                                "<td align='center'>"+price+"</td>"+
                                "<td align='center'>"+quantity+"</td>"+
                                "<td align='center'>"+discount+"</td>"+
                                "<td><button type='button' class='btn-link btn pt-0 pb-0 dropdown-item' onclick='viewDetailOfSale(+id+)'> View</button></td>"+
                                "</tr>";
                        $('#stocks').append(tr_str);

                }    
                var tr_str ="<tr>"+
                            "<td align='center'></td>"+
                            "<td align='center'>Total</td>"+
                            "<td align='center'></td>"+
                            "<td align='center'>"+result['totaldaystock']+"</td>"+
                            "<td align='center'>"+result['totaldiscountday']+"</td>"+
                        "</tr>";
                        $('#stocks').append(tr_str); 

                }
                else
                {
                alert("Ops No Stock Avaible Today");
                }
                
                }
        
        });
    }   

    function weeklyStock()
    {
        var _token = $('input[name="_token"]').val();
        $.ajax({url: "<?php echo e(route('stock.week')); ?>",
                
        success: function(result)
        {    
            // console.log(result['weekstock']);
            var len = 0;
            if(result['weekstock'] != 0)
            {
                len = result['weekstock'].length;
            }
            
            
            $('#stocks').empty();

            if(len > 0)
            {
                for(var i=0; i<len; i++)
                {
                    var id = result['weekstock'][i].id;
                    var name = result['weekstock'][i].name;
                    var price = result['weekstock'][i].price;
                    var quantity = result['weekstock'][i].quantity;
                    var discount = result['monthstock'][i].discount;
                
                    var tr_str = "<tr>"+
                                "<td align='center'>"+(i+1)+"</td>"+
                                "<td align='center'>"+name+"</td>"+
                                "<td align='center'>"+price+"</td>"+
                                "<td align='center'>"+quantity+"</td>"+
                                "<td align='center'>"+discount+"</td>"+
                                "<td><button type='button' class='btn-link btn pt-0 pb-0 dropdown-item' onclick='viewDetailOfSale(+id+)'> View</button></td>"+
                                "</tr>";
                        $('#stocks').append(tr_str);

                }
        
                var tr_str ="<tr>"+
                            "<td align='center'></td>"+
                            "<td align='center'>Total</td>"+
                            "<td align='center'></td>"+
                            "<td align='center'>"+result['totalstock']+"</td>"+
                            "<td align='center'>"+result['totalchangestock']+"</td>"+
                        "</tr>";

                    
                        $('#stocks').append(tr_str); 

                }
                else{
                        alert("Oop No Stock Record on this week ");
                }
                
                }
        
        });
    }   

    function monthlyStock()
    {
        var _token = $('input[name="_token"]').val();
        $.ajax({url: "<?php echo e(route('stock.month')); ?>",
                
        success: function(result)
        {    
            //  console.log(result['monthsales']);
            var len = 0;
            if(result['monthstock'] != 0)
            {
                len = result['monthstock'].length;
            }
            
            
            $('#stocks').empty();

            if(len > 0)
            {
                for(var i=0; i<len; i++)
                {
                    var id = result['monthstock'][i].id;
                    var name = result['monthstock'][i].name;
                    var price = result['monthstock'][i].price;
                    var quantity = result['monthstock'][i].quantity;
                    var discount = result['monthstock'][i].discount;
                
                    var tr_str = "<tr>"+
                                "<td align='center'>"+(i+1)+"</td>"+
                                "<td align='center'>"+name+"</td>"+
                                "<td align='center'>"+price+"</td>"+
                                "<td align='center'>"+quantity+"</td>"+
                                "<td align='center'>"+discount+"</td>"+
                                "<td><button type='button' class='btn-link btn pt-0 pb-0 dropdown-item' onclick='viewDetailOfSale(+id+)'> View</button></td>"+
                                "</tr>";
                        $('#stocks').append(tr_str);

                }
        
                var tr_str ="<tr>"+
                            "<td align='center'></td>"+
                            "<td align='center'>Total</td>"+
                            "<td align='center'></td>"+
                            "<td align='center'>"+result['totalstock']+"</td>"+
                            "<td align='center'>"+result['totalchangestock']+"</td>"+
                        "</tr>";

                    
                        $('#stocks').append(tr_str); 

                }
                else{
                        alert("Ops No record on this Month");
                }
                
                }
        
        });
    }   

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS\POS\resources\views/admin/report/stock/stock.blade.php ENDPATH**/ ?>